﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace MyControl
{
    public partial class MyProgressbar : UserControl
    {
        public MyProgressbar()
        {
            InitializeComponent();
            Size = new Size(300, 30);
            ForeColor = Color.FromArgb(0, 120, 212);
            Font = new Font("Arial Unicode MS", 18);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            this.SetStyle(ControlStyles.UserPaint, true);
        }

        [Description("值变更事件"), Category("自定义")]
        public event EventHandler ValueChanged;

        int m_value = 0;
        [Description("当前属性"), Category("自定义")]
        public int value
        {
            get
            {
                return m_value;
            }
            set
            {
                if (value > m_maxvalue)
                {
                    m_value = m_maxvalue;
                }
                else if (value < 0)
                {
                    m_value = 0;
                }
                else
                {
                    m_value = value;
                }
                if (ValueChanged != null)
                {
                    ValueChanged(this, null);
                }

                Refresh();
            }
        }

        private int m_maxvalue = 100;

        [Description("最大值"), Category("自定义")]
        public int Maxvalue
        {
            get
            {
                return m_maxvalue;
            }
            set
            {
                if (value < m_maxvalue)
                {
                    m_maxvalue = m_value;
                }
                else
                {
                    m_maxvalue = value;
                }
                Refresh();
            }
        }

        Color m_valuecolor = Color.FromArgb(80, 80, 80);
        [Description("值颜色"), Category("自定义")]
        public Color ValueColor
        {
            get
            {
                return m_valuecolor;
            }
            set
            {
                m_valuecolor = value;
                Refresh();
            }
        }

        private Color m_valueBGColor = Color.White;
        [Description("值背景色"), Category("自定义")]
        public Color ValueBGColor
        {
            get
            {
                return m_valueBGColor;
            }
            set
            {
                m_valueBGColor = value;
                Refresh();
            }
        }

        private Color m_borderColor = Color.Empty;
        [Description("边框色"),Category("自定义")]
        public Color BorderColor
        {
            get
            {
                return m_borderColor;
            }
            set
            {
                m_borderColor = value;
                Refresh();
            }
        }

        [Description("值字体"),Category("自定义")]
        public override Font Font
        {
            get
            {
                return base.Font;
            }
            set
            {
                base.Font = value;
                Refresh();
            }
        }

        [Description("值字体颜色"),Category("自定义")]
        public override System.Drawing.Color ForeColor
        {
            get
            {
                return base.ForeColor;
            }
            set
            {
                base.ForeColor = value;
                Refresh();
            }
        }

        private ValueDisplayType m_valueDisplayType = ValueDisplayType.Percent;
        [Description("值显示样式"),Category("自定义")]
        public ValueDisplayType valueDisplayType
        {
            get
            {
                return m_valueDisplayType;
            }
            set
            {
                m_valueDisplayType = value;
                Refresh();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            //设置GDI高质量模式抗锯齿
            g.SetGDIHigh();
            Brush brush = new SolidBrush(m_valueBGColor);
            g.FillRectangle(brush, new Rectangle(base.ClientRectangle.X, base.ClientRectangle.Y, base.ClientRectangle.Width - 3, base.ClientRectangle.Height - 2));
            GraphicsPath path = ControlHelper.CreateRoundedRectanglePath(new Rectangle(base.ClientRectangle.X, base.ClientRectangle.Y + 1, base.ClientRectangle.Width - 3, base.ClientRectangle.Height - 4),3);
            g.DrawPath(new Pen(m_borderColor, 1), path);
            LinearGradientBrush lgb = new LinearGradientBrush(new Point(0, 0), new Point(0, base.ClientRectangle.Height - 3), m_valuecolor, Color.FromArgb(200, m_valuecolor.R, m_valuecolor.G, m_valuecolor.B));
            g.FillPath(lgb, ControlHelper.CreateRoundedRectanglePath(new Rectangle(0, (base.ClientRectangle.Height - (base.ClientRectangle.Height - 3)) / 2, (base.ClientRectangle.Width - 3) * value / m_maxvalue, base.ClientRectangle.Height - 3), 3));
            string strvalue = string.Empty;
            if (m_valueDisplayType == ValueDisplayType.Percent)
            {
                strvalue = ((float)value / (float)m_maxvalue).ToString("0%");
            }
            else if (m_valueDisplayType == ValueDisplayType.Absolute)
            {
                strvalue = value + "/" + m_maxvalue;
            }
            if (!string.IsNullOrEmpty(strvalue))
            {
                System.Drawing.SizeF sizeF = g.MeasureString(strvalue, Font);
                g.DrawString(strvalue, Font, new SolidBrush(ForeColor), new PointF((this.Width - sizeF.Width) / 2, (this.Height - sizeF.Height) / 2 + 1));
            }
        }
    }
    public enum ValueDisplayType
    {
        None,
        Percent,
        Absolute
    }

}
