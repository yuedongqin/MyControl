﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace MyControl
{
    public partial class MySplitContainer : SplitContainer
    {
        const int SPLIT_BUTTON_HEIGHT = 100;
        const int SPLIT_BUTTON_WIDTH = SPLIT_BUTTON_HEIGHT;
        const int SPLIT_WIDTH_MIN = 10; // 分割条最小宽度

        //private Button splitterButton;
        private Control oldParentControl = null;
        //private event Action SplitterWidthChanged;
        private int minSplitterDistance = 0;
        private int previousSplitterDistance = 0;
        private Point pntPosition = new Point(0, 0);

        private bool bCollapse = false; // 默认展开

        //private uint top_triangle_top = 10;
        private uint triangle_width = 10;

        private bool bSplitterMouseHover = false;
        private bool bPanel1MaxWidth = false;
        private int Panel1MaxWidth = 100;

        //[Description("分割按钮鼠标按下背景色")]
        //public Color _SplitButtonMouseDownBackColor
        //{
        //    get
        //    {
        //        return this.splitterButton.FlatAppearance.MouseDownBackColor;
        //    }
        //    set
        //    {
        //        this.splitterButton.FlatAppearance.MouseDownBackColor = value;
        //        this.splitterButton.BackColor = value;
        //    }
        //}

        //[Description("分割按钮鼠标悬停背景颜色")]
        //public Color _SplitButtonMouseOverBackColor
        //{
        //    get
        //    {
        //        return this.splitterButton.FlatAppearance.MouseOverBackColor;
        //    }
        //    set
        //    {
        //        this.splitterButton.FlatAppearance.MouseOverBackColor = value;
        //    }
        //}

        [Description("从左边缘或上边缘获取或设置分割线的最小位置，以像素为单位")]
        [DefaultValue(0)]
        public int _MinSplitterDistance
        {
            get { return minSplitterDistance; }
            set { minSplitterDistance = value; }
        }

        [Description("分区线厚度")]
        [DefaultValue(10)]
        public int _SplitterWidth
        {
            get
            {
                return this.SplitterWidth;
            }
            set
            {
                this.SplitterWidth = value;
                //this.SplitterWidthChanged();
            }
        }

        [Browsable(true)]
        public new int SplitterWidth
        {
            get
            {
                return base.SplitterWidth;
            }
            set
            {
                base.SplitterWidth = value;
            }
        }

        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            this.SplitterMoved += new SplitterEventHandler(SplitterMovingCallback);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Bitmap splitterBmp = null;
            if (bSplitterMouseHover)
            {
                splitterBmp = DrawSplitterImage(Color.Silver, Color.Black, Color.Silver);
            }
            else
            {
                splitterBmp = DrawSplitterImage(Color.FromArgb(35, 35, 35), Color.FromArgb(95, 95, 95), Color.FromArgb(35, 35, 35));
            }

            Rectangle m_rect = new Rectangle();
            if (this.Orientation == System.Windows.Forms.Orientation.Vertical)//左右分割
            {
                m_rect.X = this.SplitterDistance;
                m_rect.Y = 0;
                m_rect.Width = this.SplitterWidth;
                m_rect.Height = this.Height;
            }
            else if (this.Orientation == System.Windows.Forms.Orientation.Horizontal) //上下分割
            {
                m_rect.X = 0;
                m_rect.Y = this.SplitterDistance;
                m_rect.Width = this.Width;
                m_rect.Height = this.SplitterWidth;
            }

            e.Graphics.SetClip(m_rect);
            e.Graphics.Clear(this.BackColor);

            e.Graphics.DrawImage(splitterBmp, m_rect);

        }
        public void EnablePanel1MaxConfig()
        {
            bPanel1MaxWidth = true;
        }

        public void SetPanel1MaxWidth(int width)
        {
            if (!bPanel1MaxWidth)
            {
                return;
            }

            if (width >= this.Width - 3 * SplitterWidth)
            {
                return;
            }

            Panel1MaxWidth = width;
        }
        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            SetSplitterStatus();
        }
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            SetSplitterStatus();
        }

        private void SplitterMovingCallback(object sender, SplitterEventArgs e)
        {
            if (!bPanel1MaxWidth)
            {
                //base.OnSplitterMoved(e);
            }
            else
            {
                int dis = this.SplitterDistance;
                if (dis >= Panel1MaxWidth)
                {
                    this.SplitterDistance = Panel1MaxWidth;
                }
            }
        }
        private void SetSplitterStatus()
        {
            Rectangle rect = SplitterRectangle;
            Point pt = PointToClient(Control.MousePosition);
            if (rect.Contains(pt))
            {
                bSplitterMouseHover = true;
            }
            else
            {
                bSplitterMouseHover = false;
            }
            this.Invalidate();
        }

        private Bitmap DrawSplitterImage(Color clr1, Color clr2, Color triangleColr)
        {
            Bitmap bmp = null;
            if (this.Orientation == System.Windows.Forms.Orientation.Vertical)//左右分割
            {
                bmp = new Bitmap(this.SplitterWidth, this.Height);
            }
            else if (this.Orientation == System.Windows.Forms.Orientation.Horizontal) //上下分割
            {
                bmp = new Bitmap(this.Width, this.SplitterWidth);
            }

            Graphics g = Graphics.FromImage(bmp);
            g.SetGDIHigh();
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            Brush br = null;
            if (this.Orientation == System.Windows.Forms.Orientation.Vertical)//左右分割
            {
                br = new LinearGradientBrush(rect, clr1, clr2, LinearGradientMode.Horizontal);
            }
            else if (this.Orientation == System.Windows.Forms.Orientation.Horizontal) //上下分割
            {
                br = new LinearGradientBrush(rect, clr1, clr2, LinearGradientMode.Vertical);
            }
            g.FillRectangle(br, rect);

            //绘制三角形
            Rectangle SplitRect = this.SplitterRectangle;

            //Color brushColor = Color.Black;
            Brush brush = new SolidBrush(triangleColr);
            if (this.Orientation == System.Windows.Forms.Orientation.Vertical)//左右分割
            {
                //绘制点
                for (int i = (this.Height - SPLIT_BUTTON_HEIGHT) / 2 + (int)(2 * triangle_width); i < ((this.Height + SPLIT_BUTTON_HEIGHT) / 2 - 2 * triangle_width); i += 8)
                {
                    Rectangle rt = new Rectangle(2, i, 4, 4);
                    Brush brCyc = new SolidBrush(triangleColr);
                    g.FillEllipse(brCyc, rt);
                }

                if (!bCollapse) // 如果是展开状态
                {
                    Point[] pint = new Point[3];
                    pint[0] = new Point(0, (int)((this.Height - SPLIT_BUTTON_HEIGHT + triangle_width) / 2));
                    pint[1] = new Point(SplitterWidth, (int)((this.Height - SPLIT_BUTTON_HEIGHT) / 2));
                    pint[2] = new Point(SplitterWidth, (int)(((this.Height - SPLIT_BUTTON_HEIGHT) / 2 + triangle_width)));
                    g.FillPolygon(brush, pint);

                    Point[] bottom = new Point[3];
                    bottom[0] = new Point(0, (int)((this.Height + SPLIT_BUTTON_HEIGHT - triangle_width) / 2));
                    bottom[1] = new Point(SplitterWidth, (int)(((this.Height + SPLIT_BUTTON_HEIGHT) / 2 - triangle_width)));
                    bottom[2] = new Point(SplitterWidth, (int)((this.Height + SPLIT_BUTTON_HEIGHT) / 2));
                    g.FillPolygon(brush, bottom);
                }
                else //折叠状态
                {
                    Point[] pint = new Point[3];
                    pint[0] = new Point(0, (int)((this.Height - SPLIT_BUTTON_HEIGHT) / 2));
                    pint[1] = new Point(SplitterWidth, (int)((this.Height - SPLIT_BUTTON_HEIGHT + triangle_width) / 2));
                    pint[2] = new Point(0, (int)(((this.Height - SPLIT_BUTTON_HEIGHT) / 2 + triangle_width)));
                    g.FillPolygon(brush, pint);

                    Point[] bottom = new Point[3];
                    bottom[0] = new Point(0, (int)(((this.Height + SPLIT_BUTTON_HEIGHT) / 2 - triangle_width)));
                    bottom[1] = new Point(SplitterWidth, (int)((this.Height + SPLIT_BUTTON_HEIGHT - triangle_width) / 2));
                    bottom[2] = new Point(0, (int)((this.Height + SPLIT_BUTTON_HEIGHT) / 2));
                    g.FillPolygon(brush, bottom);
                }
            }
            else if (this.Orientation == System.Windows.Forms.Orientation.Horizontal) //上下分割
            {
                //绘制点
                for (int i = (this.Width - SPLIT_BUTTON_WIDTH) / 2 + (int)(2 * triangle_width); i < ((this.Width + SPLIT_BUTTON_WIDTH) / 2 - 2 * triangle_width); i += 8)
                {
                    Rectangle rt = new Rectangle(i, 2, 4, 4);
                    Brush brCyc = new SolidBrush(triangleColr);
                    g.FillEllipse(brCyc, rt);
                }
                if (!bCollapse) // 如果是展开状态
                {
                    Point[] pint = new Point[3];
                    pint[0] = new Point((int)((this.Width - SPLIT_BUTTON_WIDTH + triangle_width) / 2), 0);
                    pint[1] = new Point((int)((this.Width - SPLIT_BUTTON_WIDTH) / 2), SplitterWidth);
                    pint[2] = new Point((int)(((this.Width - SPLIT_BUTTON_WIDTH) / 2 + triangle_width)), SplitterWidth);
                    g.FillPolygon(brush, pint);

                    Point[] bottom = new Point[3];
                    bottom[0] = new Point((int)((this.Width + SPLIT_BUTTON_WIDTH - triangle_width) / 2), 0);
                    bottom[1] = new Point((int)(((this.Width + SPLIT_BUTTON_WIDTH) / 2 - triangle_width)), SplitterWidth);
                    bottom[2] = new Point((int)((this.Width + SPLIT_BUTTON_WIDTH) / 2), SplitterWidth);
                    g.FillPolygon(brush, bottom);
                }
                else
                {
                    Point[] pint = new Point[3];
                    pint[0] = new Point((int)((this.Width - SPLIT_BUTTON_WIDTH) / 2), 0);
                    pint[1] = new Point((int)((this.Width - SPLIT_BUTTON_WIDTH + triangle_width) / 2), SplitterWidth);
                    pint[2] = new Point((int)(((this.Width - SPLIT_BUTTON_WIDTH) / 2 + triangle_width)), 0);
                    g.FillPolygon(brush, pint);

                    Point[] bottom = new Point[3];
                    bottom[0] = new Point((int)(((this.Width + SPLIT_BUTTON_WIDTH) / 2 - triangle_width)), 0);
                    bottom[1] = new Point((int)((this.Width + SPLIT_BUTTON_WIDTH - triangle_width) / 2), SplitterWidth);
                    bottom[2] = new Point((int)((this.Width + SPLIT_BUTTON_WIDTH) / 2), 0);
                    g.FillPolygon(brush, bottom);
                }
            }
            return bmp;
        }
        public MySplitContainer() : this(0, 10)
        {
            InitializeComponent();
        }
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="minSplitterDistance">从左端或顶端看到的分型线的最小位置</param>
        /// <param name="defaultSplitterWidth">默认分型线的宽度</param>
        public MySplitContainer(int minSplitterDistance, int defaultSplitterWidth)
            : base()
        {
            this.MouseDoubleClick += new MouseEventHandler(btn_Click);
            this.Resize += new EventHandler(btn_Resize);
            if (defaultSplitterWidth < SPLIT_WIDTH_MIN) // 因为需要绘制三角形和圆点，限制分割条宽度最小为SPLIT_WIDTH_MIN
            {
                defaultSplitterWidth = SPLIT_WIDTH_MIN;
            }
            this.SplitterWidth = defaultSplitterWidth;

            this.Panel1MinSize = 0;//不设置此行则无法折叠彻底，默认为25像素

        }

        /// <summary>
        /// 单击“分割按钮事件”
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btn_Click(object sender, EventArgs e)
        {
            if (this.previousSplitterDistance == 0)
            {
                this.previousSplitterDistance = this.SplitterDistance;
            }
            if (this.previousSplitterDistance == this.SplitterDistance)
            {
                this.SplitterDistance = this.minSplitterDistance;
            }
            else
            {
                this.SplitterDistance = this.previousSplitterDistance;
                this.previousSplitterDistance = 0;
            }

            bCollapse = !bCollapse;
            this.Invalidate();
        }

        void btn_Resize(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        void SplitPanel_ParentChanged(object sender, EventArgs e)
        {
            oldParentControl = this.Parent;
        }
    }
}
