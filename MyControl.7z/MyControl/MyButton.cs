﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyControl
{
    [DefaultEvent("BtnClick")]
    public partial class MyButton : MyControlBase
    {
        public MyButton()
        {
            InitializeComponent();
            this.TabStop = false;
            labelTips.Paint += labelTips_Paint;
            this.label.MouseEnter += label_MouseEnter;
            this.label.MouseLeave += label_MouseLeave;
            this.EnableMouseEffect = true;
        }

        private bool enableMouseEffect = false;
        [Description("鼠标效果"),Category("自定义")]
        public bool EnableMouseEffect
        {
            get
            {
                return enableMouseEffect;
            }
            set
            {
                enableMouseEffect = value;
            }
        }
        [Description("是否显示角标"), Category("自定义")]
        public bool IsShowTips
        {
            get
            {
                return this.labelTips.Visible;
            }
            set
            {
                this.labelTips.Visible = value;
            }
        }

        [Description("角标文字"), Category("自定义")]
        public string TipsText
        {
            get
            {
                return this.labelTips.Text;
            }
            set
            {
                this.labelTips.Text = value;
            }
        }

        private Color _btnBackColor = Color.White;
        [Description("按钮背景色"), Category("自定义")]
        public Color BtnBackColor
        {
            get
            {
                return _btnBackColor;
            }
            set
            {
                _btnBackColor = value;
                this.BackColor = value;
            }
        }

        private Color _btnFontColor = Color.White;
        [Description("按钮字体色"), Category("自定义")]
        public Color BtnFontColor
        {
            get
            {
                return _btnFontColor;
            }
            set
            {
                _btnFontColor = value;
                this.label.ForeColor = value;
            }
        }

        private Font _btnFont = new Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
        [Description("按钮字体"), Category("自定义")]
        public Font BtnFont
        {
            get
            {
                return _btnFont;
            }
            set
            {
                _btnFont = value;
                this.label.Font = value;
            }
        }

        [Description("按钮点击事件"), Category("自定义")]
        public event EventHandler BtnClick;

        private string _btnText;
        [Description("按钮文字"),Category("自定义")]
        public virtual string BtnText
        {
            get
            {
                return _btnText;
            }
            set
            {
                _btnText = value;
                this.label.Text = value;
            }
        }

        private Color m_tipsColor = Color.FromArgb(232, 30, 99);
        [Description("角标颜色"),Category("自定义")]
        public Color TipsColor
        {
            get
            {
                return m_tipsColor;
            }
            set
            {
                m_tipsColor = value;
            }
        }

        [Description("鼠标效果生效时发生，需要和MouseEffected同时使用，否则无效"), Category("自定义")]
        public event EventHandler MouseEffecting;
        [Description("鼠标效果结束时发生，需要和MouseEffecting同时使用，否则无效"), Category("自定义")]
        public event EventHandler MouseEffected;

        Color m_cacheColor = Color.Empty;
        void label_MouseLeave(object sender, EventArgs e)
        {
            if (enableMouseEffect)
            {
                if (MouseEffecting != null && MouseEffected != null)
                {
                    MouseEffected(this, e);
                }
                else
                {
                    if (m_cacheColor != Color.Empty)
                    {
                        this.FillColor = m_cacheColor;
                        m_cacheColor = Color.Empty;
                    }
                }
            }
        }

        void label_MouseEnter(object sender, EventArgs e)
        {
            if (enableMouseEffect)
            {
                if (MouseEffecting != null && MouseEffected != null)
                {
                    MouseEffecting(this, e);
                }
                else
                {
                    if (FillColor != Color.Empty && FillColor != null)
                    {
                        m_cacheColor = this.FillColor;
                        this.FillColor = this.FillColor.ChangeColor(-0.2f);
                    }
                }
            }
        }

        void labelTips_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SetGDIHigh();
            e.Graphics.FillEllipse(new SolidBrush(m_tipsColor), new Rectangle(0, 0, labelTips.Width - 1, labelTips.Height - 1));
            System.Drawing.SizeF sizeEnd = e.Graphics.MeasureString(TipsText, labelTips.Font);

            e.Graphics.DrawString(TipsText, labelTips.Font, new SolidBrush(labelTips.ForeColor), new PointF((labelTips.Width - sizeEnd.Width) / 2, (labelTips.Height - sizeEnd.Height) / 2 + 1));
        }

        private void label_MouseDown(object sender,MouseEventArgs e)
        {
            if (this.BtnClick != null)
            {
                BtnClick(this, e);
            }
        }
    }
}
