﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyControl.Datagridview
{
    [ToolboxItem(false)]
    public partial class MyDataGridViewRow : UserControl, Interface_MyDgvRow
    {

        #region 属性
        /// <summary>
        /// CheckBox选中事件
        /// </summary>
        //public event DataGridViewEventHandler CheckBoxChangeEvent;
        /// <summary>
        /// Occurs when [row custom event].
        /// </summary>
        public event DataGridViewRowCustomEventHandler RowCustomEvent;
        /// <summary>
        /// 点击单元格事件
        /// </summary>
        public event DataGridViewEventHandler CellClick;

        /// <summary>
        /// 数据源改变事件
        /// </summary>
        public event DataGridViewEventHandler SourceChanged;

        /// <summary>
        /// 列参数，用于创建列数和宽度
        /// </summary>
        /// <value>The columns.</value>
        public List<MyDgvColumnEntity> Columns
        {
            get;
            set;
        }

        /// <summary>
        /// 数据源
        /// </summary>
        /// <value>The data source.</value>
        public object DataSource
        {
            get;
            set;
        }

        /// <summary>
        /// 行号
        /// </summary>
        /// <value>The Index of the row.</value>
        public int RowIndex { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is show CheckBox.
        /// </summary>
        /// <value><c>true</c> if this instance is show CheckBox; otherwise, <c>false</c>.</value>
/*        public bool IsShowCheckBox
        {
            get;
            set;
        }
*/        /// <summary>
        /// The m is checked
        /// </summary>
        //private bool m_isChecked;
        /// <summary>
        /// 是否选中
        /// </summary>
        /// <value><c>true</c> if this instance is checked; otherwise, <c>false</c>.</value>
/*        public bool IsChecked
        {
            get
            {
                return m_isChecked;
            }

            set
            {
                if (m_isChecked != value)
                {
                    m_isChecked = value;
                    (this.panCells.Controls.Find("check", false)[0] as MyCheckBox).Checked = value;
                }
            }
        }
*/        /// <summary>
        /// The m row height
        /// </summary>
        int m_rowHeight = 40;
        /// <summary>
        /// 行高
        /// </summary>
        /// <value>The height of the row.</value>
        public int RowHeight
        {
            get
            {
                return m_rowHeight;
            }
            set
            {
                m_rowHeight = value;
                this.Height = value;
            }
        }

        //public bool IsShowCheckBox { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public bool IsChecked { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        #endregion
        public MyDataGridViewRow()
        {
            InitializeComponent();
        }

        public void BindingCellData()
        {
            if (DataSource != null)
            {
                for (int i = 0; i < Columns.Count; i++)
                {
                    MyDgvColumnEntity col = Columns[i];
                    var cs = this.panCells.Controls.Find("lbl_" + col.DataField, false);
                    if (cs != null && cs.Length > 0)
                    {
                        if (DataSource is DataRow)
                        {
                            DataRow row = DataSource as DataRow;
                            if (col.Format != null)
                            {
                                cs[0].Text = col.Format(row[col.DataField]);
                            }
                            else
                            {
                                cs[0].Text = ((row[col.DataField]) == null) ? string.Empty : (row[col.DataField]).ToString();
                            }
                        }
                        else
                        {
                            var pro = DataSource.GetType().GetProperty(col.DataField);
                            if (pro != null)
                            {
                                var value = pro.GetValue(DataSource, null);
                                if (col.Format != null)
                                {
                                    cs[0].Text = col.Format(value);
                                }
                                else
                                {
                                    cs[0].Text = (value == null) ? string.Empty : value.ToString();
                                }
                            }
                        }
                    }
                }
            }

            foreach (Control item in this.panCells.Controls)
            {
                if (item is Interface_MyDgvCustomCell)
                {
                    Interface_MyDgvCustomCell cell = item as Interface_MyDgvCustomCell;
                    cell.RowCustomEvent += Cell_RowCustomEvent;
                    cell.SetBindSource(DataSource);
                }
            }


        }

        private void Cell_RowCustomEvent(object sender, MyDgvRowEvent e)
        {
            if (RowCustomEvent != null)
            {
                RowCustomEvent(sender, e);
            }
        }

        void Item_MouseDown(object sender, MouseEventArgs e)
        {
            if (CellClick != null)
            {
                CellClick(this, new MyDgvEvent()
                {
                    CellControl = this,
                    CellIndex = (int)(sender as Control).Tag,
                    RowIndex = this.RowIndex
                });
            }
        }


        public void ReloadCells()
        {
            try
            {
                ControlHelper.FreezeControl(this, true);
                this.panCells.Controls.Clear();
                this.panCells.ColumnStyles.Clear();
                int colCount = Columns.Count;
                if (Columns != null && colCount >0)
                {
                    //if (IsShowCheckBox)
                    //{
                    //    colCount++;
                    //}
                    this.panCells.ColumnCount = colCount;
                    for (int i = 0; i < colCount; i++)
                    {
                        Control c = null;
                        var item = Columns[i];
                        this.panCells.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(item.WidthType, item.Width));
                        if (item.CustomCellType == null)
                        {
                            Label lbl = new Label();
                            lbl.Tag = i;
                            lbl.Name = "lbl_" + item.DataField;
                            lbl.Font = new Font("微软雅黑", 9);
                            lbl.ForeColor = Color.Black;
                            lbl.AutoSize = false;
                            lbl.Dock = DockStyle.Fill;
                            lbl.TextAlign = item.TextAlign;
                            lbl.MouseDown += (a, b) =>
                            {
                                Item_MouseDown(a, b);
                            };
                            c = lbl;
                        }
                        else
                        {
                            Control cc = (Control)Activator.CreateInstance(item.CustomCellType);
                            cc.Dock = DockStyle.Fill;
                            c = cc;
                        }
                        this.panCells.Controls.Add(c, i, 0);
                    }
                    
                }
            }
            finally
            {

                ControlHelper.FreezeControl(this, false);
            }
        }

        public void SetSelect(bool blnSelected)
        {
            if (blnSelected)
            {
                this.BackColor = Color.FromArgb(0, 120, 215);
            }
            else
            {
                this.BackColor = Color.Transparent;
            }
        }

    }
}
