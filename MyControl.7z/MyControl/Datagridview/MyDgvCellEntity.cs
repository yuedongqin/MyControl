﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyControl.Datagridview
{
    public class MyDgvCellEntity
    {
        public string Title { get; set; }

        public int Width { get; set; }

        public System.Windows.Forms.SizeType WidthType { get; set; }

    }
}
