﻿namespace MyControl.Datagridview
{
    partial class MyDataGridViewRow
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.myHorizontalSplitLine = new MyHorizontalSplitLine();
            this.panCells = new System.Windows.Forms.TableLayoutPanel();
            this.SuspendLayout();

            this.myHorizontalSplitLine.BackColor = System.Drawing.Color.FromArgb(232, 232, 232);
            this.myHorizontalSplitLine.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.myHorizontalSplitLine.Location = new System.Drawing.Point(0, 55);
            this.myHorizontalSplitLine.Name = "HorizontalSplitLine";
            this.myHorizontalSplitLine.Size = new System.Drawing.Size(660, 1);
            this.myHorizontalSplitLine.TabIndex = 0;
            this.myHorizontalSplitLine.TabStop = false;

            this.panCells.ColumnCount = 1;
            this.panCells.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.panCells.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panCells.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCells.Location = new System.Drawing.Point(0, 0);
            this.panCells.Name = "panCells";
            this.panCells.RowCount = 1;
            this.panCells.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.panCells.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panCells.Size = new System.Drawing.Size(661, 55);
            this.panCells.TabIndex = 1;

            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panCells);
            this.Controls.Add(this.myHorizontalSplitLine);
            this.Name = "MyDataGridViewItem";
            this.Size = new System.Drawing.Size(660, 56);
            this.ResumeLayout(false);
        }

        #endregion

        private MyHorizontalSplitLine myHorizontalSplitLine;
        private System.Windows.Forms.TableLayoutPanel panCells;
    }
}
