﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyControl.Datagridview
{
    public class MyDgvEvent : EventArgs
    {

        public Control CellControl { get; set; }

        public int CellIndex { get; set; }

        public int RowIndex { get;set; }
        
    }
}
