﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace MyControl.Datagridview
{
    public class MyDgvColumnEntity
    {

        public string HeadText { get; set; }

        public int Width { get; set; }

        public System.Windows.Forms.SizeType WidthType { get; set; }

        public string DataField { get; set; }

        public Func<object, string> Format { get; set; }

        private ContentAlignment _TextAlign = ContentAlignment.MiddleCenter;
        public ContentAlignment TextAlign
        {
            get { return _TextAlign; }
            set { _TextAlign = value; }
        }

        private Type customCellType = null;
        public Type CustomCellType
        {
            get
            {
                return customCellType;
            }
            set
            {
                if (!typeof(Interface_MyDgvCustomCell).IsAssignableFrom(value) || !value.IsSubclassOf(typeof(System.Windows.Forms.Control)))
                {
                    throw new Exception("行控件未实现IDataGridViewCustomCell接口");
                }
                customCellType = value;
            }
        }
    }
}
