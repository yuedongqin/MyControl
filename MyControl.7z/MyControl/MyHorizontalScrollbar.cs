﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace MyControl
{
    [Designer(typeof(ScrollbarControlDesigner))]
    [DefaultEvent("Scroll")]
    public class MyHorizontalScrollbar : MyControlBase
    {
        #region 属性  
        
        
        
        protected int moLargeChange = 10;
        
        
        
        protected int moSmallChange = 1;
        
        
        
        protected int moMinimum = 0;
        
        
        
        protected int moMaximum = 100;
        
        
        
        protected int moValue = 0;
        
        
        
        private int nClickPoint;
        
        
        
        protected int moThumbLeft = 0;
        
        
        
        protected bool moAutoSize = false;
        
        
        
        private bool moThumbMouseDown = false;
        
        
        
        private bool moThumbMouseDragging = false;
        
        
        
        public new event EventHandler Scroll = null;
        
        
        
        public event EventHandler ValueChanged = null;

        
        
        
        private int btnWidth = 18;
        
        
        
        private int m_intThumbMinWidth = 15;

        
        
        
        
        public int BtnWidth
        {
            get { return btnWidth; }
            set { btnWidth = value; }
        }
        
        
        
        
        [EditorBrowsable(EditorBrowsableState.Always), Browsable(true), DefaultValue(false), Category("自定义"), Description("LargeChange")]
        public int LargeChange
        {
            get { return moLargeChange; }
            set
            {
                moLargeChange = value;
                Invalidate();
            }
        }

        
        
        
        
        [EditorBrowsable(EditorBrowsableState.Always), Browsable(true), DefaultValue(false), Category("自定义"), Description("SmallChange")]
        public int SmallChange
        {
            get { return moSmallChange; }
            set
            {
                moSmallChange = value;
                Invalidate();
            }
        }

        
        
        
        
        [EditorBrowsable(EditorBrowsableState.Always), Browsable(true), DefaultValue(false), Category("自定义"), Description("Minimum")]
        public int Minimum
        {
            get { return moMinimum; }
            set
            {
                moMinimum = value;
                Invalidate();
            }
        }

        
        
        
        
        [EditorBrowsable(EditorBrowsableState.Always), Browsable(true), DefaultValue(false), Category("自定义"), Description("Maximum")]
        public int Maximum
        {
            get { return moMaximum; }
            set
            {
                moMaximum = value;
                Invalidate();
            }
        }

        
        
        
        
        [EditorBrowsable(EditorBrowsableState.Always), Browsable(true), DefaultValue(false), Category("自定义"), Description("Value")]
        public int Value
        {
            get { return moValue; }
            set
            {
                moValue = value;
                if (moValue > moMaximum)
                    moValue = moMaximum;
                int nTrackWidth = (this.Width - btnWidth * 2);
                float fThumbWidth = nTrackWidth - Maximum;
                
                int nThumbWidth = (int)fThumbWidth;

                if (nThumbWidth > nTrackWidth)
                {
                    nThumbWidth = nTrackWidth;
                    fThumbWidth = nTrackWidth;
                }
                if (nThumbWidth < m_intThumbMinWidth)
                {
                    nThumbWidth = m_intThumbMinWidth;
                    fThumbWidth = m_intThumbMinWidth;
                }

                
                int nPixelRange = nTrackWidth - nThumbWidth;
                int nRealRange = (Maximum - Minimum) - LargeChange;
                float fPerc = 0.0f;
                if (nRealRange != 0)
                {
                    fPerc = (float)moValue / (float)nRealRange;

                }

                float fLeft = fPerc * nPixelRange;
                moThumbLeft = (int)fLeft;


                Invalidate();
            }
        }

        
        
        
        
        public override bool AutoSize
        {
            get
            {
                return base.AutoSize;
            }
            set
            {
                base.AutoSize = value;
                if (base.AutoSize)
                {
                    this.Width = 15;
                }
            }
        }

        
        
        
        private Color thumbColor = Color.FromArgb(115, 115, 115);

        
        
        
        
        public Color ThumbColor
        {
            get { return thumbColor; }
            set { thumbColor = value; }
        }
        #endregion

        public MyHorizontalScrollbar()
        {
            InitializeComponent();
            CornerRadius = 2;
            FillColor = Color.FromArgb(239, 239, 239);
            IsShowRect = false;
            IsRadius = true;
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.SetStyle(ControlStyles.Selectable, true);
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            this.SetStyle(ControlStyles.UserPaint, true);
        }
        
        
        
        private void InitializeComponent()
        {
            this.SuspendLayout();

            this.MinimumSize = new System.Drawing.Size(0, 10);
            this.Name = "UCHScrollbar";
            this.Size = new System.Drawing.Size(150, 18);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CustomScrollbar_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CustomScrollbar_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CustomScrollbar_MouseUp);
            this.ResumeLayout(false);

        }

        #region 鼠标事件    English:Mouse event
        
        
        
        
        
        private void CustomScrollbar_MouseDown(object sender, MouseEventArgs e)
        {
            if (Maximum <= 0)
            {
                return;
            }
            Point ptPoint = this.PointToClient(Cursor.Position);
            int nTrackWidth = (this.Width - btnWidth * 2);
            float fThumbWidth = nTrackWidth - Maximum;
            
            int nThumbWidth = (int)fThumbWidth;

            if (nThumbWidth > nTrackWidth)
            {
                nThumbWidth = nTrackWidth;
                fThumbWidth = nTrackWidth;
            }
            if (nThumbWidth < m_intThumbMinWidth)
            {
                nThumbWidth = m_intThumbMinWidth;
                fThumbWidth = m_intThumbMinWidth;
            }

            int nLeft = moThumbLeft;
            nLeft += btnWidth;


            Rectangle thumbrect = new Rectangle(new Point(nLeft, 1), new Size(nThumbWidth, this.Height - 2));
            
            if (thumbrect.Contains(ptPoint))
            {
                
                nClickPoint = (ptPoint.X - nLeft);
                this.moThumbMouseDown = true;
            }
            else
            {
                
                Rectangle leftarrowrect = new Rectangle(new Point(0, 1), new Size(btnWidth, this.Height));
                if (leftarrowrect.Contains(ptPoint))
                {
                    int nRealRange = (Maximum - Minimum) - LargeChange;
                    int nPixelRange = (nTrackWidth - nThumbWidth);
                    if (nRealRange > 0)
                    {
                        if (nPixelRange > 0)
                        {
                            if ((moThumbLeft - SmallChange) < 0)
                                moThumbLeft = 0;
                            else
                                moThumbLeft -= SmallChange;

                            
                            float fPerc = (float)moThumbLeft / (float)nPixelRange;
                            float fValue = fPerc * (Maximum - LargeChange);

                            moValue = (int)fValue;

                            if (ValueChanged != null)
                                ValueChanged(this, new EventArgs());

                            if (Scroll != null)
                                Scroll(this, new EventArgs());

                            Invalidate();
                        }
                    }
                }
                else
                {
                    Rectangle rightarrowrect = new Rectangle(new Point(btnWidth + nTrackWidth, 1), new Size(btnWidth, this.Height));
                    if (rightarrowrect.Contains(ptPoint))
                    {
                        int nRealRange = (Maximum - Minimum) - LargeChange;
                        int nPixelRange = (nTrackWidth - nThumbWidth);
                        if (nRealRange > 0)
                        {
                            if (nPixelRange > 0)
                            {
                                if ((moThumbLeft + SmallChange) > nPixelRange)
                                    moThumbLeft = nPixelRange;
                                else
                                    moThumbLeft += SmallChange;

                                
                                float fPerc = (float)moThumbLeft / (float)nPixelRange;
                                float fValue = fPerc * (Maximum - LargeChange);

                                moValue = (int)fValue;

                                if (ValueChanged != null)
                                    ValueChanged(this, new EventArgs());

                                if (Scroll != null)
                                    Scroll(this, new EventArgs());

                                Invalidate();
                            }
                        }
                    }
                }
            }
        }

        
        
        
        
        
        private void CustomScrollbar_MouseUp(object sender, MouseEventArgs e)
        {
            this.moThumbMouseDown = false;
            this.moThumbMouseDragging = false;
            Application.DoEvents();
        }

        
        
        
        
        private void MoveThumb(int x)
        {
            int nRealRange = Maximum - Minimum;
            int nTrackWidth = (this.Width - btnWidth * 2);
            
            float fThumbWidth = nTrackWidth - Maximum;
            int nThumbWidth = (int)fThumbWidth;

            if (nThumbWidth > nTrackWidth)
            {
                nThumbWidth = nTrackWidth;
                fThumbWidth = nTrackWidth;
            }
            if (nThumbWidth < m_intThumbMinWidth)
            {
                nThumbWidth = m_intThumbMinWidth;
                fThumbWidth = m_intThumbMinWidth;
            }

            int nSpot = nClickPoint;

            int nPixelRange = (nTrackWidth - nThumbWidth);
            if (moThumbMouseDown && nRealRange > 0)
            {
                if (nPixelRange > 0)
                {
                    int nNewThumbLeft = x - (btnWidth + nSpot);

                    if (nNewThumbLeft < 0)
                    {
                        moThumbLeft = nNewThumbLeft = 0;
                    }
                    else if (nNewThumbLeft > nPixelRange)
                    {
                        moThumbLeft = nNewThumbLeft = nPixelRange;
                    }
                    else
                    {
                        moThumbLeft = x - (btnWidth + nSpot);
                    }


                    float fPerc = (float)moThumbLeft / (float)nPixelRange;
                    float fValue = fPerc * (Maximum - (nNewThumbLeft == nPixelRange ? 0 : LargeChange));
                    
                    if (Math.Abs(moValue - fValue) < 1)
                    {
                        return;
                    }
                    moValue = (int)fValue;
                    Invalidate();

                    try
                    {
                        Application.DoEvents();
                    }
                    catch { }
                }
            }
        }

        
        
        
        
        
        private void CustomScrollbar_MouseMove(object sender, MouseEventArgs e)
        {
            if (!moThumbMouseDown)
                return;

            if (moThumbMouseDown == true)
            {
                this.moThumbMouseDragging = true;
            }

            if (this.moThumbMouseDragging)
            {
                MoveThumb(e.X);
            }

            if (ValueChanged != null)
                ValueChanged(this, new EventArgs());

            if (Scroll != null)
                Scroll(this, new EventArgs());
        }
        #endregion

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SetGDIHigh();
            if (Maximum > 0)
            {
                
                int nTrackWidth = (this.Width - btnWidth * 2);
                
                float fThumbWidth = nTrackWidth - Maximum;
                int nThumbWidth = (int)fThumbWidth;

                if (nThumbWidth > nTrackWidth)
                {
                    nThumbWidth = nTrackWidth;
                    fThumbWidth = nTrackWidth;
                }
                if (nThumbWidth < m_intThumbMinWidth)
                {
                    nThumbWidth = m_intThumbMinWidth;
                    fThumbWidth = m_intThumbMinWidth;
                }
                int nLeft = moThumbLeft;
                nLeft += btnWidth;
                if (nLeft + nThumbWidth > this.Width - btnWidth)
                    nLeft = this.Width - btnWidth - nThumbWidth;
                e.Graphics.FillPath(new SolidBrush(thumbColor), new Rectangle(nLeft, 1, nThumbWidth, this.Height - 3).CreateRoundedRectanglePath(this.CornerRadius));
            }
            ControlHelper.PaintTriangle(e.Graphics, new SolidBrush(thumbColor), new Point(btnWidth - Math.Min(5, this.Height / 2), this.Height / 2), Math.Min(5, this.Height / 2), ControlHelper.GraphDirection.Leftward);
            ControlHelper.PaintTriangle(e.Graphics, new SolidBrush(thumbColor), new Point(this.Width - (btnWidth - Math.Min(5, this.Height / 2)), this.Height / 2), Math.Min(5, this.Height / 2), ControlHelper.GraphDirection.Rightward);

        }

    }
}
