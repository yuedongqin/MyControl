﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyControl
{
    [DefaultEvent("BtnClick")]
    public partial class MyButtonWithImg : MyButton
    {
        private string _btnText = "ButtonImg";
        /// <summary>
        /// 按钮文字
        /// </summary>
        /// <value>The BTN text.</value>
        [Description("按钮文字"), Category("自定义")]
        public override string BtnText
        {
            get { return _btnText; }
            set
            {
                _btnText = value;
                label.Text = value;
                label.Refresh();
            }
        }

        [Description("图片"), Category("自定义")]
        public virtual Image Image
        {
            get
            {
                return this.label.Image;
            }
            set
            {
                this.label.Image = value;
            }
        }

        [Description("图片位置"), Category("自定义")]
        public virtual ContentAlignment ImageAlign
        {
            get { return this.label.ImageAlign; }
            set { label.ImageAlign = value; }
        }
        /// <summary>
        /// 文字位置
        /// </summary>
        /// <value>The text align.</value>
        [Description("文字位置"), Category("自定义")]
        public virtual ContentAlignment TextAlign
        {
            get { return this.label.TextAlign; }
            set { label.TextAlign = value; }
        }

        public MyButtonWithImg()
        {
            InitializeComponent();
            IsShowTips = false;
        }
    }
}
